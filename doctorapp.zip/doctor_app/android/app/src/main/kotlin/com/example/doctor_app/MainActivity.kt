package com.example.doctor_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
